#ifndef SIMULATION_H_INCLUDED
#define SIMULATION_H_INCLUDED
#include "Vehicule.h"
#include "graphe.h"
#include <vector>
#include <QGraphicsScene>
#include <QGraphicsLineItem>
#include "hexagone.h"
class MainWindow;
class Simulation {

private:
    friend class MainWindow;
    std::vector<Vehicule*> vehicules; // Liste des pointeurs vers des véhicules
    graphe* grapheInstance;
    int nombreVehicules;
    void initialiserVehicules(); // Initialiser les véhicules
    void deplacerVehicules();
    void dessinerConnexions(QGraphicsScene* scene);
    Vehicule* trouverVehiculeParId(int id);
    void mettreAJourConnexions(QGraphicsScene* scene);
    void afficherCouverture(QGraphicsScene* scene);
    QMap<QPair<int, int>, QGraphicsLineItem*> connexionsMap; // Associe chaque connexion (par ID) à une ligne
    std::vector<hexagone*> d_hexagones; // Liste des hexagones
    const double HEX_RADIUS = 500.0;    // Rayon des hexagones
    const double SEUIL_PUISSANCE = 0.01;
    const double MAX_PUISSANCE = 100.0;
    void genererGrilleHexagones(QGraphicsScene* scene, double rayon);
    void mettreAJourCouvertureHexagones();
    int vitesseSimulation;
public:
    Simulation(int nbVehicules);
    ~Simulation(); // Destructeur
    void affichage(QGraphicsScene* scene);
    int getVitesseSimulation() const;
    void accelerer();
    void ralentir();

};

#endif // SIMULATION_H_INCLUDED
