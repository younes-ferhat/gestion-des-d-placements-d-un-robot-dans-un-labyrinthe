#include "Simulation.h"
#include <iostream>
#include <QDebug>
#include <QGraphicsScene>
#include <QPoint>
#include <QRandomGenerator>


Simulation::Simulation(int nbVehicules)
    : nombreVehicules(nbVehicules), grapheInstance(nullptr), vitesseSimulation(2000) {
    grapheInstance = new graphe();
}


Simulation::~Simulation() {
    // Libérer la mémoire des véhicules et du graphe
    for (Vehicule* vehicule : vehicules) {
        delete vehicule;
    }
    delete grapheInstance;
}


void Simulation::accelerer() {
    if (vitesseSimulation > 500) {
        vitesseSimulation -= 500;
    }
}

void Simulation::ralentir() {
    if (vitesseSimulation < 5000) {
        vitesseSimulation += 500;
    }
}

int Simulation::getVitesseSimulation() const {
    return vitesseSimulation;
}



void Simulation::initialiserVehicules() {
    // UTILISER LES NŒUDS SUR LES ROUTES (listeNoeudsReferences)
    QMap<long long, noeud*> noeudsRoutes = grapheInstance->getListeNoeudsReferences();

    if (noeudsRoutes.isEmpty()) {
        qWarning() << "❌ Aucun nœud de route disponible!";
        return;
    }

    qDebug() << "🚗 Initialisation avec" << noeudsRoutes.size() << "nœuds de routes disponibles";

    // OPTIMISATION 1: Réserver la mémoire à l'avance
    vehicules.reserve(nombreVehicules);

    // Convertir en liste pour accès aléatoire plus rapide
    QList<noeud*> listeNoeuds = noeudsRoutes.values();
    int tailleMap = listeNoeuds.size();

    // NOUVEAU: Suivre les nœuds déjà utilisés pour éviter les superpositions
    QSet<long long> noeudsUtilises;
    const double DISTANCE_MIN = 0.001; // Distance minimale entre véhicules (en degrés, ~100m)

    for (int i = 0; i < nombreVehicules; ++i) {
        noeud* noeudDepart = nullptr;
        noeud* noeudDestination = nullptr;

        // STRATÉGIE D'ESPACEMENT: Chercher un nœud loin des autres véhicules
        int tentativesEspacement = 0;
        const int MAX_TENTATIVES = 50;

        while (tentativesEspacement < MAX_TENTATIVES) {
            int indexDepart = QRandomGenerator::global()->bounded(tailleMap);
            noeud* candidat = listeNoeuds[indexDepart];

            // Vérifier si ce nœud est assez loin des autres véhicules
            bool assezLoin = true;

            for (Vehicule* autreVehicule : vehicules) {
                noeud* autrePos = autreVehicule->getPosition();
                double distLat = std::abs(candidat->getLatitude() - autrePos->getLatitude());
                double distLon = std::abs(candidat->getLongitude() - autrePos->getLongitude());
                double distance = std::sqrt(distLat * distLat + distLon * distLon);

                if (distance < DISTANCE_MIN) {
                    assezLoin = false;
                    break;
                }
            }

            if (assezLoin) {
                noeudDepart = candidat;
                break;
            }

            tentativesEspacement++;
        }

        // Si on n'a pas trouvé après MAX_TENTATIVES, prendre un nœud au hasard
        if (!noeudDepart) {
            int indexDepart = QRandomGenerator::global()->bounded(tailleMap);
            noeudDepart = listeNoeuds[indexDepart];
        }

        // Choisir une destination loin du départ
        int tentativesDestination = 0;
        while (tentativesDestination < 20) {
            int indexDest = QRandomGenerator::global()->bounded(tailleMap);
            noeud* candidatDest = listeNoeuds[indexDest];

            // La destination doit être à au moins 0.005° du départ (~500m)
            double distLat = std::abs(candidatDest->getLatitude() - noeudDepart->getLatitude());
            double distLon = std::abs(candidatDest->getLongitude() - noeudDepart->getLongitude());
            double distance = std::sqrt(distLat * distLat + distLon * distLon);

            if (distance > 0.005) {
                noeudDestination = candidatDest;
                break;
            }

            tentativesDestination++;
        }

        // Si pas de destination lointaine trouvée, prendre au hasard
        if (!noeudDestination) {
            int indexDest = QRandomGenerator::global()->bounded(tailleMap);
            noeudDestination = listeNoeuds[indexDest];
        }

        if (noeudDepart && noeudDestination) {
            Vehicule* vehicule = new Vehicule(i + 1, 100, 2.4);

            // OPTIMISATION: Vitesse adaptative selon le nombre de véhicules
            double vitesse = 0.015;
            if (nombreVehicules > 100) {
                vitesse = 0.025;
            }
            if (nombreVehicules > 300) {
                vitesse = 0.04;
            }
            vehicule->setVitesseDeplacement(vitesse);

            vehicule->setPosition(noeudDepart);
            vehicules.push_back(vehicule);

            // Calculer le chemin immédiatement
            QVector<noeud*> chemin = grapheInstance->calculerCheminDijkstra(noeudDepart, noeudDestination);

            if (chemin.isEmpty()) {
                qWarning() << "⚠️ Véhicule" << i+1 << ": pas de chemin trouvé";
                chemin.append(noeudDepart);
            }

            vehicule->setChemin(chemin);

            if (i < 5 || i % 50 == 0) {
                qDebug() << "✓ Véhicule" << i+1 << "position:"
                         << QString::number(noeudDepart->getLatitude(), 'f', 4) << ","
                         << QString::number(noeudDepart->getLongitude(), 'f', 4)
                         << "→" << QString::number(noeudDestination->getLatitude(), 'f', 4) << ","
                         << QString::number(noeudDestination->getLongitude(), 'f', 4)
                         << "(" << chemin.size() << "nœuds)";
            }
        }
    }

    qDebug() << "✅ Total:" << vehicules.size() << "véhicules ESPACÉS initialisés sur toute la carte";
}


void Simulation::deplacerVehicules() {
    // OPTIMISATION 4: Parcours optimisé avec nœuds de routes
    QList<noeud*> noeudsRoutes = grapheInstance->getListeNoeudsReferences().values();
    int tailleMap = noeudsRoutes.size();

    if (tailleMap == 0) {
        qWarning() << "Aucun nœud de route disponible pour déplacement!";
        return;
    }

    for (int i = 0; i < vehicules.size(); ++i) {
        Vehicule* vehicule = vehicules[i];

        QPointF posActuelle = vehicule->getPositionSmooth();
        QPointF posCible = vehicule->getPosition()->geoToScene();

        // Calcul optimisé de distance (sans sqrt si possible)
        double dx = posActuelle.x() - posCible.x();
        double dy = posActuelle.y() - posCible.y();
        double distanceCarree = dx * dx + dy * dy;

        // Seuil de distance (4 pixels² = 2 pixels de distance)
        if (distanceCarree < 4.0) {
            noeud* prochainePosition;
            if(vehicule->getVersAvant())
                prochainePosition = vehicule->avancerChemin();
            else
                prochainePosition = vehicule->reculerChemin();

            if (prochainePosition) {
                vehicule->setPosition(prochainePosition);
            } else {
                // Fin du chemin atteinte, choisir une NOUVELLE destination sur les routes
                int indexDestination = QRandomGenerator::global()->bounded(tailleMap);
                noeud* nouvelleDestination = noeudsRoutes[indexDestination];

                if (nouvelleDestination && nouvelleDestination != vehicule->getPosition()) {
                    QVector<noeud*> nouveauChemin = grapheInstance->calculerCheminDijkstra(
                        vehicule->getPosition(),
                        nouvelleDestination
                        );

                    if (!nouveauChemin.isEmpty()) {
                        vehicule->setChemin(nouveauChemin);

                        // Log occasionnel
                        if (i % 20 == 0) {
                            qDebug() << "🔄 Véhicule" << vehicule->getId() << "nouveau trajet vers"
                                     << QString::number(nouvelleDestination->getLatitude(), 'f', 4) << ","
                                     << QString::number(nouvelleDestination->getLongitude(), 'f', 4);
                        }
                    } else {
                        // Si pas de chemin, choisir un autre nœud aléatoire
                        int tentatives = 0;
                        while (nouveauChemin.isEmpty() && tentatives < 5) {
                            indexDestination = QRandomGenerator::global()->bounded(tailleMap);
                            nouvelleDestination = noeudsRoutes[indexDestination];
                            nouveauChemin = grapheInstance->calculerCheminDijkstra(
                                vehicule->getPosition(),
                                nouvelleDestination
                                );
                            tentatives++;
                        }

                        if (!nouveauChemin.isEmpty()) {
                            vehicule->setChemin(nouveauChemin);
                        } else {
                            // En dernier recours, créer un chemin minimal
                            nouveauChemin.append(vehicule->getPosition());
                            vehicule->setChemin(nouveauChemin);
                        }
                    }
                }
            }
        }
    }
}

void Simulation::mettreAJourConnexions(QGraphicsScene* scene) {
    // OPTIMISATION 5: Limiter les connexions affichées pour les grandes simulations
    int maxConnexionsParVehicule = 3;
    if (nombreVehicules > 100) {
        maxConnexionsParVehicule = 2; // Moins de connexions pour plus de véhicules
    }
    if (nombreVehicules > 200) {
        maxConnexionsParVehicule = 1; // Encore moins
    }

    QList<QPair<int, int>> connexionsASupprimer = connexionsMap.keys();

    // OPTIMISATION 6: Utiliser un index spatial simple
    for (int i = 0; i < vehicules.size(); ++i) {
        Vehicule* vehiculeA = vehicules[i];

        QPointF positionA = vehiculeA->getPositionSmooth();
        double rayonA = vehiculeA->calculerRayonCouverture();

        QMultiMap<double, int> connexionsPossibles;

        // Commencer à i+1 pour éviter les doublons
        for (int j = i + 1; j < vehicules.size(); ++j) {
            Vehicule* vehiculeB = vehicules[j];

            QPointF positionB = vehiculeB->getPositionSmooth();

            // Calcul optimisé
            double dx = positionA.x() - positionB.x();
            double dy = positionA.y() - positionB.y();
            double distanceCarree = dx * dx + dy * dy;

            double rayonMax = rayonA + vehiculeB->calculerRayonCouverture();
            double rayonMaxCarre = rayonMax * rayonMax;

            if (distanceCarree <= rayonMaxCarre) {
                double distance = std::sqrt(distanceCarree);
                connexionsPossibles.insert(distance, j);
            }
        }

        int count = 0;
        for (auto it = connexionsPossibles.begin();
             it != connexionsPossibles.end() && count < maxConnexionsParVehicule;
             ++it, ++count) {

            int indexB = it.value();
            Vehicule* vehiculeB = vehicules[indexB];
            double distance = it.key();

            QPointF positionB = vehiculeB->getPositionSmooth();

            int idA = vehiculeA->getId();
            int idB = vehiculeB->getId();
            QPair<int, int> connexion(qMin(idA, idB), qMax(idA, idB));

            double rayonMax = rayonA + vehiculeB->calculerRayonCouverture();
            double ratio = distance / rayonMax;

            QColor couleur = QColor::fromHsv(
                120 - static_cast<int>(ratio * 120),
                200,
                255,
                140
                );

            QPen pen(couleur, 0.8);
            pen.setStyle(Qt::DashLine);

            if (!connexionsMap.contains(connexion)) {
                QGraphicsLineItem* ligne = scene->addLine(
                    QLineF(positionA, positionB),
                    pen
                    );
                ligne->setZValue(80);
                connexionsMap[connexion] = ligne;

                vehiculeA->connecteDe(vehiculeB->getId());
                vehiculeB->connecteDe(vehiculeA->getId());
            } else {
                QGraphicsLineItem* ligne = connexionsMap[connexion];
                ligne->setLine(QLineF(positionA, positionB));
                ligne->setPen(pen);
            }

            connexionsASupprimer.removeOne(connexion);
        }
    }

    // Nettoyage
    for (const QPair<int, int>& connexion : connexionsASupprimer) {
        if (connexionsMap.contains(connexion)) {
            QGraphicsLineItem* ligne = connexionsMap[connexion];
            scene->removeItem(ligne);
            delete ligne;
            connexionsMap.remove(connexion);
        }
    }
}



void Simulation::genererGrilleHexagones(QGraphicsScene* scene, double rayon) {
    QRectF limitesGeo = grapheInstance->obtenirLimitesGeo();
    double minX = limitesGeo.left();
    double minY = limitesGeo.top();
    double maxX = limitesGeo.right();
    double maxY = limitesGeo.bottom();

    double hexWidth = 2 * rayon * std::sqrt(3) / 2;
    double hexHeight = 2 * rayon;
    int rows = static_cast<int>((maxY - minY) / (hexHeight * 0.75));
    int cols = static_cast<int>((maxX - minX) / hexWidth);

    for (int row = 0; row < rows; ++row) {
        for (int col = 0; col < cols; ++col) {
            double cx = minX + col * hexWidth;
            double cy = minY + row * hexHeight * 0.75;

            if (row % 2 == 1) {
                cx += hexWidth / 2;
            }

            if (cx + rayon <= maxX && cy + rayon <= maxY) {
                QPointF centre(cx, cy);
                hexagone* hex = new hexagone(centre, rayon);
                scene->addItem(hex);
                d_hexagones.push_back(hex);
            }
        }
    }
}




void Simulation::mettreAJourCouvertureHexagones() {
    for (hexagone* hex : d_hexagones) {
        double puissanceTotale = 0.0;

        for (Vehicule* vehicule : vehicules) {
            QPoint vehiculePos = vehicule->getPositionSmooth().toPoint();

            double distance = std::sqrt(
                std::pow(hex->getCentre().x() - vehiculePos.x(), 2) +
                std::pow(hex->getCentre().y() - vehiculePos.y(), 2)
                );

            double rayon = vehicule->calculerRayonCouverture();
            if (distance <= rayon) {
                puissanceTotale += vehicule->calculerPuissance(distance);
            }
        }

        if (puissanceTotale > SEUIL_PUISSANCE) {
            hex->setBrush(QBrush(QColor::fromHsvF(0.0, 1.0, puissanceTotale / MAX_PUISSANCE, 0.5)));
        } else {
            hex->setBrush(QBrush(Qt::gray));
        }
        hex->update();
    }
}




void Simulation::affichage(QGraphicsScene* scene)
{
    for(int i=0; i<nombreVehicules; i++)
    {
        vehicules[i]->afficherDansScene(scene);
    }
    mettreAJourConnexions(scene);
    deplacerVehicules();
}
