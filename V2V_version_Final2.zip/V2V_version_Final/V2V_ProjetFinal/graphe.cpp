#include "graphe.h"
#include <QFile>
#include <QXmlStreamReader>
#include <QDebug>
#include <QGraphicsEllipseItem>
#include <QGraphicsLineItem>
#include "mainwindow.h"
#include <QRandomGenerator>
#include <QPainterPath>
#include <QGraphicsPathItem>

graphe::graphe() {}

// Getters
QMap<long long, noeud*> graphe::getListeNoeuds() const {
    return listeNoeuds;
}
QMap<long long, noeud*> graphe::getListeNoeudsReferences() const{
    return listeNoeudsReferences;
}

QVector<arete*> graphe::getListeAretes() const {
    return listeAretes;
}


void graphe::afficherGraphe(QGraphicsScene* scene) const {
    if (listeNoeuds.isEmpty() || listeAretes.isEmpty()) {
        qWarning() << "Le graphe est vide ou incomplet.";
        return;
    }

    qDebug() << "Graphe chargé avec" << listeNoeuds.size() << "nœuds et"
             << listeAretes.size() << "arêtes (non affichés sur la carte).";
}


// Ajout de nœuds et d'arêtes
void graphe::ajouteNoeud(noeud* node) {
    listeNoeuds[node->getId()] = node;
}

void graphe::ajouteArete(arete* edge) {
    listeAretes.append(edge);
}

// NOUVELLE VERSION : Charger TOUTES les routes de la carte
void graphe::chargerDepuisOSM(const QString& fichierOSM) {
    QFile file(fichierOSM);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qWarning("Impossible d'ouvrir le fichier.");
        return;
    }

    QXmlStreamReader xml(&file);

    QMap<long long, noeud*> noeudsTemp;

    // IMPORTANT: Charger TOUS les types de routes, pas seulement quelques-unes
    QStringList typesRoutesPracticables = {
        "motorway", "trunk", "primary", "secondary", "tertiary",
        "unclassified", "residential", "service",
        "motorway_link", "trunk_link", "primary_link", "secondary_link", "tertiary_link",
        "living_street", "road"
    };

    qDebug() << "🔄 Chargement du fichier OSM...";

    // ÉTAPE 1: Charger TOUS les nœuds
    while (!xml.atEnd() && !xml.hasError()) {
        QXmlStreamReader::TokenType token = xml.readNext();

        if (token == QXmlStreamReader::StartElement) {
            if (xml.name() == QString("node")) {
                long long id = xml.attributes().value("id").toLongLong();
                double lat = xml.attributes().value("lat").toDouble();
                double lon = xml.attributes().value("lon").toDouble();

                noeud* newNode = new noeud(id, lat, lon);
                listeNoeuds[id] = newNode;
                noeudsTemp[id] = newNode;
            }
        }
    }

    qDebug() << "✓ Phase 1:" << listeNoeuds.size() << "nœuds chargés";

    // ÉTAPE 2: Recharger le fichier pour les routes
    file.seek(0);
    xml.setDevice(&file);

    int routesChargees = 0;
    int noeudsRoutes = 0;

    while (!xml.atEnd() && !xml.hasError()) {
        QXmlStreamReader::TokenType token = xml.readNext();

        if (token == QXmlStreamReader::StartElement) {
            if (xml.name() == QString("way")) {
                QVector<long long> noeudsDeLArrete;
                QString type;
                bool estRoute = false;

                while (!(xml.tokenType() == QXmlStreamReader::EndElement && xml.name() ==  QString("way"))) {
                    xml.readNext();

                    if (xml.tokenType() == QXmlStreamReader::StartElement) {
                        if (xml.name() == QString("nd")) {
                            long long ref = xml.attributes().value("ref").toLongLong();
                            noeudsDeLArrete.append(ref);
                        } else if (xml.name() == QString("tag")) {
                            if (xml.attributes().value("k") == QString("highway")) {
                                type = xml.attributes().value("v").toString();
                                if (typesRoutesPracticables.contains(type)) {
                                    estRoute = true;
                                }
                            }
                        }
                    }
                }

                // Si c'est une route praticable, ajouter TOUS ses nœuds
                if (estRoute && noeudsDeLArrete.size() >= 2) {
                    routesChargees++;

                    for (long long id : noeudsDeLArrete) {
                        noeud* refNode = noeudsTemp.value(id, nullptr);
                        if (refNode && !listeNoeudsReferences.contains(id)) {
                            listeNoeudsReferences[id] = refNode;
                            noeudsRoutes++;
                        }
                    }

                    // Créer les arêtes et connexions
                    for (int i = 0; i < noeudsDeLArrete.size() - 1; ++i) {
                        long long idDebut = noeudsDeLArrete[i];
                        long long idFin = noeudsDeLArrete[i + 1];

                        noeud* debut = noeudsTemp.value(idDebut, nullptr);
                        noeud* fin = noeudsTemp.value(idFin, nullptr);

                        if (debut && fin) {
                            // Connexion bidirectionnelle
                            debut->ajouterVoisin(fin);
                            fin->ajouterVoisin(debut);

                            arete* newEdge = new arete(debut, fin);
                            newEdge->setType(type);
                            newEdge->setPoids(newEdge->getDistanceLambert93());
                            listeAretes.append(newEdge);
                        }
                    }
                }
            }
        }
    }

    if (xml.hasError()) {
        qWarning() << "Erreur lors de la lecture du fichier OSM :" << xml.errorString();
    }

    file.close();

    qDebug() << "✓ Phase 2:" << routesChargees << "routes chargées";
    qDebug() << "✓ Phase 3:" << noeudsRoutes << "nœuds de routes référencés";
    qDebug() << "✓ Phase 4:" << listeAretes.size() << "arêtes créées";

    // Vérifier la connectivité
    verifierConnectivite();

    qDebug() << "========================================";
    qDebug() << "📊 RÉSUMÉ DU CHARGEMENT:";
    qDebug() << "   Total nœuds carte:" << listeNoeuds.size();
    qDebug() << "   Nœuds sur routes:" << listeNoeudsReferences.size();
    qDebug() << "   Routes chargées:" << routesChargees;
    qDebug() << "   Arêtes créées:" << listeAretes.size();
    qDebug() << "========================================";
}

void graphe::verifierConnectivite() {
    if (listeNoeudsReferences.isEmpty()) {
        qWarning() << "⚠️ Aucun nœud de route chargé!";
        return;
    }

    // Vérifier quelques nœuds aléatoires
    QList<noeud*> noeuds = listeNoeudsReferences.values();
    int noeudsConnectes = 0;
    int noeudsSansVoisins = 0;

    for (int i = 0; i < qMin(100, noeuds.size()); i++) {
        noeud* n = noeuds[i];
        int nbVoisins = n->getNoeudsVoisins().size();
        if (nbVoisins > 0) {
            noeudsConnectes++;
        } else {
            noeudsSansVoisins++;
        }
    }

    double pourcentageConnecte = (noeudsConnectes * 100.0) / qMin(100, noeuds.size());

    qDebug() << "🔗 Connectivité (échantillon 100 nœuds):";
    qDebug() << "   Nœuds connectés:" << noeudsConnectes << "(" << pourcentageConnecte << "%)";
    qDebug() << "   Nœuds isolés:" << noeudsSansVoisins;

    if (pourcentageConnecte < 50) {
        qWarning() << "⚠️ ATTENTION: Faible connectivité du graphe!";
    }
}

noeud* graphe::getNoeudAleatoire() const {
    if (listeNoeudsReferences.isEmpty()) {
        qWarning() << "Liste de nœuds de routes vide!";
        return nullptr;
    }

    QList<long long> ids = listeNoeudsReferences.keys();
    int indexAleatoire = QRandomGenerator::global()->bounded(ids.size());
    long long idAleatoire = ids[indexAleatoire];
    noeud* node = listeNoeudsReferences.value(idAleatoire, nullptr);

    return node;
}

QRectF graphe::obtenirLimitesGeo() const {
    if (listeNoeuds.isEmpty()) return QRectF();

    double minLongitude = std::numeric_limits<double>::max();
    double maxLongitude = std::numeric_limits<double>::lowest();
    double minLatitude = std::numeric_limits<double>::max();
    double maxLatitude = std::numeric_limits<double>::lowest();

    for (const auto& noeud : listeNoeuds) {
        double longitude = noeud->getLongitude();
        double latitude = noeud->getLatitude();
        minLongitude = std::min(minLongitude, longitude);
        maxLongitude = std::max(maxLongitude, longitude);
        minLatitude = std::min(minLatitude, latitude);
        maxLatitude = std::max(maxLatitude, latitude);
    }

    noeud* Nmin = new noeud(0,minLongitude, minLatitude);
    noeud* Nmax = new noeud(1,maxLongitude, maxLatitude);
    return QRectF(Nmin->geoToScene(), Nmax->geoToScene());
}

void graphe::testerNoeudVoisins() const {
    if (listeNoeuds.isEmpty()) {
        qWarning() << "La liste des nœuds est vide.";
        return;
    }

    QList<long long> ids = listeNoeuds.keys();
    int indexAleatoire = QRandomGenerator::global()->bounded(ids.size());
    long long idAleatoire = ids[indexAleatoire];
    noeud* noeudAleatoire = listeNoeuds.value(idAleatoire);

    if (noeudAleatoire) {
        qDebug() << "Nœud aléatoire ID :" << noeudAleatoire->getId()
            << "a" << noeudAleatoire->getNoeudsVoisins().size() << "voisins.";
    }
}

QVector<noeud*> graphe::calculerCheminDijkstra(noeud* debut, noeud* fin) {
    QMap<noeud*, double> distances;
    QMap<noeud*, noeud*> predecesseurs;
    QSet<noeud*> visites;
    QVector<noeud*> chemin;

    // Utiliser seulement les nœuds sur les routes
    for (auto noeud : listeNoeudsReferences) {
        distances[noeud] = std::numeric_limits<double>::infinity();
    }
    distances[debut] = 0;

    auto comparerDistances = [&distances](noeud* a, noeud* b) {
        return distances[a] < distances[b];
    };

    QList<noeud*> file = listeNoeudsReferences.values();

    while (!file.isEmpty()) {
        std::sort(file.begin(), file.end(), comparerDistances);
        noeud* noeudActuel = file.takeFirst();

        if (noeudActuel == fin) {
            break;
        }

        visites.insert(noeudActuel);
        for (noeud* voisin : noeudActuel->getNoeudsVoisins()) {
            if (visites.contains(voisin)) {
                continue;
            }

            double distance = std::sqrt(
                std::pow(noeudActuel->getLongitude() - voisin->getLongitude(), 2) +
                std::pow(noeudActuel->getLatitude() - voisin->getLatitude(), 2)
                );

            double nouvelleDistance = distances[noeudActuel] + distance;
            if (nouvelleDistance < distances[voisin]) {
                distances[voisin] = nouvelleDistance;
                predecesseurs[voisin] = noeudActuel;
            }
        }
    }

    // Reconstruction du chemin
    noeud* current = fin;
    while (current) {
        chemin.prepend(current);
        current = predecesseurs.value(current, nullptr);
    }

    return chemin;
}
