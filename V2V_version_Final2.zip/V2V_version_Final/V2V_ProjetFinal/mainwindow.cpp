#include "mainwindow.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QMessageBox>
#include <QFileDialog>
#include <QKeyEvent>
#include <QInputDialog>
#include <QProgressDialog>
#include <QTimer>
#include <QtMath>
#include <limits>
#include <QDebug>


MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent), timer(new QTimer(this)), renderTimer(nullptr),
    tileManager(new OSMTileManager(this)), tilesLoaded(false) {
    setupUI();
}

MainWindow::~MainWindow() {
    delete simulation;
}

void MainWindow::setupUI() {
    QWidget *centralWidget = new QWidget(this);
    QVBoxLayout *mainLayout = new QVBoxLayout;

    // Titre
    QLabel *titleLabel = new QLabel("🗺️ Simulation V2V - avec carte OpenStreetMap");
    titleLabel->setAlignment(Qt::AlignCenter);
    titleLabel->setStyleSheet(
        "font-size: 20px; "
        "font-weight: bold; "
        "color: #2c3e50; "
        "padding: 10px; "
        "background: qlineargradient(x1:0, y1:0, x2:1, y2:0, "
        "stop:0 #3498db, stop:1 #2ecc71); "
        "color: white; "
        "border-radius: 5px;"
        );
    mainLayout->addWidget(titleLabel);

    // Carte
    scene = new QGraphicsScene(this);
    scene->setBackgroundBrush(QBrush(QColor(240, 248, 255)));

    mapView = new QGraphicsView(scene);
    mapView->setStyleSheet(
        "border: 2px solid #34495e; "
        "border-radius: 8px;"
        );
    mapView->setMinimumSize(1000, 700);

    // OPTIMISATION: Rendu adaptatif selon le nombre de véhicules
    mapView->setRenderHint(QPainter::Antialiasing, true);
    mapView->setRenderHint(QPainter::SmoothPixmapTransform, true);
    mapView->setRenderHint(QPainter::TextAntialiasing, true);

    // Mode de mise à jour optimisé
    mapView->setViewportUpdateMode(QGraphicsView::MinimalViewportUpdate);
    mapView->setCacheMode(QGraphicsView::CacheBackground);

    // Activer le drag pour déplacer la carte
    mapView->setDragMode(QGraphicsView::ScrollHandDrag);

    mainLayout->addWidget(mapView);
    simulation = new Simulation(15);

    // Boutons
    QHBoxLayout *buttonLayout = new QHBoxLayout;
    buttonLayout->setSpacing(10);

    loadOSMButton = new QPushButton("🗺️ Charger Carte OSM");
    zoomInButton = new QPushButton("🔍 Zoom +");
    zoomOutButton = new QPushButton("🔍 Zoom -");
    speedUpButton = new QPushButton("⚡ Accélérer");
    slowButton = new QPushButton("🐌 Ralentir");
    stopButton = new QPushButton("⏸ Pause");
    resumeButton = new QPushButton("▶ Reprendre");
    resumeButton->setEnabled(false);

    QString buttonStyle =
        "QPushButton {"
        "   background-color: #3498db;"
        "   color: white;"
        "   border: none;"
        "   padding: 10px 16px;"
        "   border-radius: 5px;"
        "   font-weight: bold;"
        "   font-size: 13px;"
        "}"
        "QPushButton:hover {"
        "   background-color: #2980b9;"
        "}"
        "QPushButton:pressed {"
        "   background-color: #21618c;"
        "}"
        "QPushButton:disabled {"
        "   background-color: #bdc3c7;"
        "}";

    loadOSMButton->setStyleSheet(buttonStyle);
    zoomInButton->setStyleSheet(buttonStyle);
    zoomOutButton->setStyleSheet(buttonStyle);
    speedUpButton->setStyleSheet(buttonStyle);
    slowButton->setStyleSheet(buttonStyle);

    QString stopStyle = buttonStyle;
    stopStyle.replace("#3498db", "#e74c3c");
    stopStyle.replace("#2980b9", "#c0392b");
    stopButton->setStyleSheet(stopStyle);

    QString resumeStyle = buttonStyle;
    resumeStyle.replace("#3498db", "#27ae60");
    resumeStyle.replace("#2980b9", "#229954");
    resumeButton->setStyleSheet(resumeStyle);

    buttonLayout->addWidget(loadOSMButton);
    buttonLayout->addWidget(zoomInButton);
    buttonLayout->addWidget(zoomOutButton);
    buttonLayout->addWidget(speedUpButton);
    buttonLayout->addWidget(slowButton);
    buttonLayout->addWidget(stopButton);
    buttonLayout->addWidget(resumeButton);
    buttonLayout->addStretch();

    mainLayout->addLayout(buttonLayout);

    // Info
    QLabel *infoLabel = new QLabel(
        "💡 Molette pour zoomer | Clic-glisser pour déplacer | "
        "Les tuiles OSM sont téléchargées automatiquement | "
        "Recommandé: max 300 véhicules pour de bonnes performances"
        );
    infoLabel->setStyleSheet(
        "color: #7f8c8d; "
        "font-size: 11px; "
        "padding: 5px;"
        );
    infoLabel->setWordWrap(true);
    mainLayout->addWidget(infoLabel);

    centralWidget->setLayout(mainLayout);
    setCentralWidget(centralWidget);

    // Connexions
    connect(zoomInButton, &QPushButton::clicked, this, &MainWindow::zoomIn);
    connect(zoomOutButton, &QPushButton::clicked, this, &MainWindow::zoomOut);
    connect(speedUpButton, &QPushButton::clicked, this, &MainWindow::accelerer);
    connect(slowButton, &QPushButton::clicked, this, &MainWindow::ralentir);
    connect(loadOSMButton, &QPushButton::clicked, this, [this]() {
        demanderNombreVehicules();
        loadOSMData();
    });
    connect(stopButton, &QPushButton::clicked, this, &MainWindow::stopSimulation);
    connect(resumeButton, &QPushButton::clicked, this, &MainWindow::resumeSimulation);
    connect(tileManager, &OSMTileManager::toutesChargees, this, &MainWindow::onTuilesChargees);
}

void MainWindow::loadOSMData() {
    QString filePath = QFileDialog::getOpenFileName(
        this,
        "Charger un fichier OSM",
        "",
        "Fichiers OSM (*.osm)"
        );

    if (!filePath.isEmpty()) {
        // Charger les données du graphe
        simulation->grapheInstance->chargerDepuisOSM(filePath);
        simulation->initialiserVehicules();

        // Charger les tuiles de carte OSM
        chargerTuilesOSM();
    }
}

void MainWindow::chargerTuilesOSM() {
    // Obtenir les limites géographiques du graphe
    QMap<long long, noeud*> noeuds = simulation->grapheInstance->getListeNoeuds();

    if (noeuds.isEmpty()) {
        QMessageBox::warning(this, "Erreur", "Aucun nœud chargé!");
        return;
    }

    // Calculer les limites min/max
    double minLat = std::numeric_limits<double>::max();
    double maxLat = std::numeric_limits<double>::lowest();
    double minLon = std::numeric_limits<double>::max();
    double maxLon = std::numeric_limits<double>::lowest();

    for (const auto& noeud : noeuds) {
        minLat = qMin(minLat, noeud->getLatitude());
        maxLat = qMax(maxLat, noeud->getLatitude());
        minLon = qMin(minLon, noeud->getLongitude());
        maxLon = qMax(maxLon, noeud->getLongitude());
    }

    // Ajouter une marge de 2%
    double margeLat = (maxLat - minLat) * 0.02;
    double margeLon = (maxLon - minLon) * 0.02;
    minLat -= margeLat;
    maxLat += margeLat;
    minLon -= margeLon;
    maxLon += margeLon;

    qDebug() << "Zone géographique:" << minLat << "-" << maxLat << "," << minLon << "-" << maxLon;

    // Charger les tuiles (zoom 15 = bon niveau de détail pour les villes)
    int zoomLevel = 15;

    QMessageBox::information(
        this,
        "Chargement",
        QString("Téléchargement des tuiles OpenStreetMap...\n"
                "Zone: lat=%1 à %2, lon=%3 à %4\n"
                "Cela peut prendre quelques secondes.")
            .arg(minLat, 0, 'f', 4)
            .arg(maxLat, 0, 'f', 4)
            .arg(minLon, 0, 'f', 4)
            .arg(maxLon, 0, 'f', 4)
        );

    tileManager->chargerTuilesPourZone(scene, minLat, maxLat, minLon, maxLon, zoomLevel);
}

void MainWindow::onTuilesChargees() {
    qDebug() << "Toutes les tuiles OSM sont chargées!";
    tilesLoaded = true;

    // Afficher le graphe par-dessus les tuiles
    afficherCarte();

    QMessageBox::information(
        this,
        "Carte chargée",
        QString("La carte OpenStreetMap a été chargée avec succès!\n"
                "Vous pouvez maintenant voir vos %1 véhicules sur la vraie carte.")
            .arg(simulation->nombreVehicules)
        );
}

void MainWindow::afficherCarte() {
    qDebug() << "Affichage de la carte avec" << simulation->nombreVehicules << "véhicules";
    qDebug() << "Rect de la scène:" << scene->sceneRect();

    // Afficher le graphe routier (avec transparence pour voir la carte dessous)
    simulation->grapheInstance->afficherGraphe(scene);

    // Afficher les véhicules
    for (int i = 0; i < simulation->nombreVehicules; i++) {
        simulation->vehicules[i]->afficherDansScene(scene);
    }

    // Mettre à jour les connexions
    simulation->mettreAJourConnexions(scene);

    // OPTIMISATION: Timer de rendu adaptatif selon le nombre de véhicules
    int fpsRendu = 60; // 60 FPS par défaut
    if (simulation->nombreVehicules > 100) {
        fpsRendu = 30; // 30 FPS pour 100-200 véhicules
    }
    if (simulation->nombreVehicules > 200) {
        fpsRendu = 20; // 20 FPS pour plus de 200 véhicules
    }

    int intervalRendu = 1000 / fpsRendu;

    if (!renderTimer) {
        // Timer pour le rendu visuel
        renderTimer = new QTimer(this);
        connect(renderTimer, &QTimer::timeout, this, [this]() {
            // Mise à jour visuelle uniquement (interpolation)
            for (int i = 0; i < simulation->nombreVehicules; i++) {
                simulation->vehicules[i]->afficherDansScene(scene);
            }
            simulation->mettreAJourConnexions(scene);
        });
    }
    renderTimer->start(intervalRendu);

    // Timer pour la logique de déplacement
    int intervalLogique = 100; // Base 100ms
    if (simulation->nombreVehicules > 100) {
        intervalLogique = 150; // Plus lent pour beaucoup de véhicules
    }
    if (simulation->nombreVehicules > 200) {
        intervalLogique = 200;
    }

    if (!timer->isActive()) {
        connect(timer, &QTimer::timeout, this, [this]() {
            simulation->deplacerVehicules();
            // Désactiver hexagones pour grandes simulations
            if (simulation->nombreVehicules < 100) {
                simulation->mettreAJourCouvertureHexagones();
            }
        });
    }
    timer->start(intervalLogique);

    stopButton->setEnabled(true);
    resumeButton->setEnabled(false);

    // Ajuster la vue pour voir toute la scène
    if (!scene->items().isEmpty()) {
        QRectF bounds = scene->itemsBoundingRect();
        qDebug() << "Bounds des items:" << bounds;
        mapView->fitInView(bounds, Qt::KeepAspectRatio);
        mapView->scale(0.9, 0.9); // Zoom out un peu pour voir les bords
    }

    qDebug() << "Simulation démarrée avec intervalle rendu:" << intervalRendu
             << "ms et intervalle logique:" << intervalLogique << "ms";
}

void MainWindow::zoomIn() {
    mapView->scale(1.2, 1.2);
}

void MainWindow::zoomOut() {
    mapView->scale(0.8, 0.8);
}

void MainWindow::accelerer() {
    simulation->accelerer();
    timer->setInterval(simulation->getVitesseSimulation());
}

void MainWindow::ralentir() {
    simulation->ralentir();
    timer->setInterval(simulation->getVitesseSimulation());
}

void MainWindow::stopSimulation() {
    timer->stop();
    if (renderTimer) renderTimer->stop();
    stopButton->setEnabled(false);
    resumeButton->setEnabled(true);
}

void MainWindow::resumeSimulation() {
    // Recalculer les intervalles au cas où
    int intervalLogique = 100;
    if (simulation->nombreVehicules > 100) intervalLogique = 150;
    if (simulation->nombreVehicules > 200) intervalLogique = 200;

    timer->start(intervalLogique);

    if (renderTimer) {
        int fpsRendu = 60;
        if (simulation->nombreVehicules > 100) fpsRendu = 30;
        if (simulation->nombreVehicules > 200) fpsRendu = 20;
        renderTimer->start(1000 / fpsRendu);
    }

    stopButton->setEnabled(true);
    resumeButton->setEnabled(false);
}

void MainWindow::wheelEvent(QWheelEvent *event) {
    if (event->angleDelta().y() > 0) {
        zoomIn();
    } else {
        zoomOut();
    }
}

void MainWindow::keyPressEvent(QKeyEvent *event) {
    if (event->key() == Qt::Key_Plus) {
        zoomIn();
    } else if (event->key() == Qt::Key_Minus) {
        zoomOut();
    }
}

void MainWindow::demanderNombreVehicules() {
    bool ok;
    int nombreVehicules = QInputDialog::getInt(
        this,
        tr("Nombre de Véhicules"),
        tr("Entrez le nombre de véhicules pour la simulation :\n"
           "(Recommandé: max 300 pour de bonnes performances)"),
        10, 1, 500, 1, &ok
        );

    if (ok) {
        if (nombreVehicules > 300) {
            QMessageBox::StandardButton reponse = QMessageBox::warning(
                this,
                "Attention",
                QString("Vous avez choisi %1 véhicules.\n"
                        "Les performances peuvent être dégradées au-delà de 300 véhicules.\n"
                        "Voulez-vous continuer ?").arg(nombreVehicules),
                QMessageBox::Yes | QMessageBox::No
                );

            if (reponse == QMessageBox::No) {
                demanderNombreVehicules(); // Redemander
                return;
            }
        }

        delete simulation;
        simulation = new Simulation(nombreVehicules);
    } else {
        QMessageBox::information(this, "Annulé", "La simulation n'a pas été initialisée.");
    }
}
