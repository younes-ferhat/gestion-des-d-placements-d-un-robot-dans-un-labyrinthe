#ifndef VEHICULE_H
#define VEHICULE_H

#include "noeud.h"
#include <QGraphicsScene>
#include <QGraphicsEllipseItem>
#include <QGraphicsItem>
#include <unordered_set>
#include <QPointF>
#include <QPropertyAnimation>

class Vehicule {
private:
    int id;
    double puissance;
    double frequence;
    noeud* position;
    noeud* noeudPrecedent;

    QGraphicsItem* graphicItem;
    QGraphicsEllipseItem* couvertureItem;
    std::unordered_set<int> vehiclesConnectes;

    QVector<noeud*> chemin;
    int indexCheminActuel;
    bool versAvant;

    // Pour le mouvement smooth
    QPointF positionActuelle;      // Position interpolée actuelle
    QPointF positionCible;         // Position cible (prochain noeud)
    double progressionMouvement;   // Entre 0.0 et 1.0
    double vitesseDeplacement;     // Vitesse d'interpolation (0.0 à 1.0 par frame)

public:
    Vehicule(int ident, double p, double f);

    // Getters et setters
    int getId();
    noeud* getPosition() const;
    void setPosition(noeud* val);
    double getPuissance();
    double getFrequence();
    void setPuissance(double val);

    // Gestion des connexions
    std::unordered_set<int> getConnexions() const;
    void connecteDe(int idVB);
    void deconnecteDe(int idVB);
    bool estConnecteAvec(int idVB) const;

    // Calculs
    double calculerRayonCouverture() const;
    double calculerPuissance(double distance) const;

    // Affichage
    QGraphicsItem* getEllipse() const;
    void afficherDansScene(QGraphicsScene* scene);

    // Gestion du chemin
    void setChemin(const QVector<noeud*>& nouveauChemin);
    QVector<noeud*> getChemin() const;
    noeud* avancerChemin();
    noeud* reculerChemin();
    noeud* getPositionCheminActuel() const;
    bool getVersAvant();

    // Mouvement smooth
    void updatePositionSmooth();           // Mettre à jour l'interpolation
    QPointF getPositionSmooth() const;     // Obtenir position interpolée
    void setVitesseDeplacement(double vitesse); // Régler la vitesse (0.01 à 0.5)
};

#endif // VEHICULE_H
