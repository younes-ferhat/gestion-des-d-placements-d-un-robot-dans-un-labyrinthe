QT       += core gui xml

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++17
QT += location positioning
QT += location
QT += svgwidgets

#QT += core gui widgets webenginewidgets


# You can make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

SOURCES += \
    Simulation.cpp \
    Vehicule.cpp \
    arete.cpp \
    graphe.cpp \
    hexagone.cpp \
    main.cpp \
    mainwindow.cpp \
    noeud.cpp \
    osmtilemanager.cpp \
    point.cpp \
    sommet.cpp

HEADERS += \
    Simulation.h \
    Vehicule.h \
    arete.h \
    graphe.h \
    hexagone.h \
    mainwindow.h \
    noeud.h \
    osmtilemanager.h \
    point.h \
    sommet.h

FORMS += \
   mainwindow.ui

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target

DISTFILES +=

RESOURCES += \
    resources.qrc
