#include "osmtilemanager.h"
#include <QNetworkRequest>
#include <QUrl>
#include <QDebug>
#include <QDir>
#include <QStandardPaths>
#include <cmath>
#include <QThread>

OSMTileManager::OSMTileManager(QObject* parent)
    : QObject(parent), networkManager(new QNetworkAccessManager(this)),
    currentScene(nullptr), totalTuiles(0), tuilesChargees(0), currentZoom(15) {

    // Créer le dossier de cache s'il n'existe pas
    QDir cacheDir(QStandardPaths::writableLocation(QStandardPaths::CacheLocation) + "/osm_tiles");
    if (!cacheDir.exists()) {
        cacheDir.mkpath(".");
    }
}

OSMTileManager::~OSMTileManager() {
    clear();
}

QPair<int, int> OSMTileManager::latLonToTile(double lat, double lon, int zoom) {
    // Formule de conversion OSM standard
    int n = 1 << zoom; // 2^zoom
    int tileX = static_cast<int>(floor((lon + 180.0) / 360.0 * n));
    int tileY = static_cast<int>(floor((1.0 - asinh(tan(lat * M_PI / 180.0)) / M_PI) / 2.0 * n));
    return QPair<int, int>(tileX, tileY);
}

QPointF OSMTileManager::tileToScene(int tileX, int tileY, int zoom) const {
    // Chaque tuile fait 256x256 pixels
    const int tileSize = 256;

    // Calculer la position en pixels
    double x = tileX * tileSize;
    double y = tileY * tileSize;

    // Échelle pour correspondre à votre projection Lambert93
    // Vous devrez ajuster ce facteur selon votre carte
    double scale = 1.0;

    return QPointF(x * scale, y * scale);
}

void OSMTileManager::chargerTuilesPourZone(QGraphicsScene* scene, double minLat, double maxLat,
                                           double minLon, double maxLon, int zoomLevel) {
    if (!scene) return;

    currentScene = scene;
    currentZoom = zoomLevel;
    tuilesChargees = 0;

    // Calculer les tuiles nécessaires
    QPair<int, int> topLeft = latLonToTile(maxLat, minLon, zoomLevel);
    QPair<int, int> bottomRight = latLonToTile(minLat, maxLon, zoomLevel);

    int minTileX = qMin(topLeft.first, bottomRight.first);
    int maxTileX = qMax(topLeft.first, bottomRight.first);
    int minTileY = qMin(topLeft.second, bottomRight.second);
    int maxTileY = qMax(topLeft.second, bottomRight.second);

    totalTuiles = (maxTileX - minTileX + 1) * (maxTileY - minTileY + 1);

    qDebug() << "Chargement de" << totalTuiles << "tuiles OSM...";
    qDebug() << "Zone:" << minTileX << "à" << maxTileX << "," << minTileY << "à" << maxTileY;

    // Télécharger toutes les tuiles nécessaires
    for (int x = minTileX; x <= maxTileX; ++x) {
        for (int y = minTileY; y <= maxTileY; ++y) {
            telechargerTuile(x, y, zoomLevel);
        }
    }
}

void OSMTileManager::telechargerTuile(int tileX, int tileY, int zoom) {
    QPair<int, int> tileKey(tileX, tileY);

    // Vérifier si déjà chargée
    if (tuiles.contains(tileKey)) {
        return;
    }

    // Essayer de charger depuis le cache
    QPixmap pixmap;
    if (chargerDepuisCache(tileX, tileY, zoom, pixmap)) {
        QGraphicsPixmapItem* item = currentScene->addPixmap(pixmap);
        QPointF pos = tileToScene(tileX, tileY, zoom);
        item->setPos(pos);
        item->setZValue(-10); // En arrière-plan
        tuiles[tileKey] = item;

        tuilesChargees++;
        emit tuileChargee(tileX, tileY);

        if (tuilesChargees >= totalTuiles) {
            emit toutesChargees();
        }
        return;
    }

    // Télécharger depuis OSM
    // URL des serveurs de tuiles OSM
    // Format: https://tile.openstreetmap.org/{z}/{x}/{y}.png
    QString url = QString("https://tile.openstreetmap.org/%1/%2/%3.png")
                      .arg(zoom)
                      .arg(tileX)
                      .arg(tileY);

    QNetworkRequest request(url);
    // Important: respecter la politique d'utilisation d'OSM
    request.setHeader(QNetworkRequest::UserAgentHeader, "V2V Simulation/1.0");

    QNetworkReply* reply = networkManager->get(request);

    // Stocker les coordonnées de la tuile pour le callback
    reply->setProperty("tileX", tileX);
    reply->setProperty("tileY", tileY);
    reply->setProperty("zoom", zoom);

    connect(reply, &QNetworkReply::finished, this, &OSMTileManager::onTuileTelechargee);

    // Délai pour respecter les limites d'OSM (pas trop de requêtes simultanées)

}

void OSMTileManager::onTuileTelechargee() {
    QNetworkReply* reply = qobject_cast<QNetworkReply*>(sender());
    if (!reply) return;

    int tileX = reply->property("tileX").toInt();
    int tileY = reply->property("tileY").toInt();
    int zoom = reply->property("zoom").toInt();

    if (reply->error() == QNetworkReply::NoError) {
        QByteArray data = reply->readAll();
        QPixmap pixmap;
        pixmap.loadFromData(data);

        if (!pixmap.isNull()) {
            // Sauvegarder dans le cache
            sauverDansCache(tileX, tileY, zoom, data);

            // Ajouter à la scène
            QGraphicsPixmapItem* item = currentScene->addPixmap(pixmap);
            QPointF pos = tileToScene(tileX, tileY, zoom);
            item->setPos(pos);
            item->setZValue(-10); // En arrière-plan

            QPair<int, int> tileKey(tileX, tileY);
            tuiles[tileKey] = item;

            tuilesChargees++;
            emit tuileChargee(tileX, tileY);

            qDebug() << "Tuile chargée:" << tileX << tileY << "(" << tuilesChargees << "/" << totalTuiles << ")";

            if (tuilesChargees >= totalTuiles) {
                qDebug() << "Toutes les tuiles sont chargées!";
                emit toutesChargees();
            }
        }
    } else {
        qWarning() << "Erreur de téléchargement de tuile:" << reply->errorString();
        tuilesChargees++; // Compter quand même pour débloquer
    }

    reply->deleteLater();
}

QString OSMTileManager::getCachePath(int tileX, int tileY, int zoom) const {
    QString cachePath = QStandardPaths::writableLocation(QStandardPaths::CacheLocation) + "/osm_tiles";
    return QString("%1/%2_%3_%4.png").arg(cachePath).arg(zoom).arg(tileX).arg(tileY);
}

void OSMTileManager::sauverDansCache(int tileX, int tileY, int zoom, const QByteArray& data) {
    QString filePath = getCachePath(tileX, tileY, zoom);
    QFile file(filePath);
    if (file.open(QIODevice::WriteOnly)) {
        file.write(data);
        file.close();
    }
}

bool OSMTileManager::chargerDepuisCache(int tileX, int tileY, int zoom, QPixmap& pixmap) {
    QString filePath = getCachePath(tileX, tileY, zoom);
    if (QFile::exists(filePath)) {
        return pixmap.load(filePath);
    }
    return false;
}

void OSMTileManager::clear() {
    for (auto item : tuiles.values()) {
        if (currentScene && item) {
            currentScene->removeItem(item);
            delete item;
        }
    }
    tuiles.clear();
    tuilesChargees = 0;
    totalTuiles = 0;
}
