#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QPushButton>
#include <QTimer>
#include <QWheelEvent>
#include <QKeyEvent>
#include "Simulation.h"
#include "osmtilemanager.h"

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget* parent = nullptr);
    ~MainWindow();

protected:
    void wheelEvent(QWheelEvent* event) override;
    void keyPressEvent(QKeyEvent* event) override;

private slots:
    void loadOSMData();
    void zoomIn();
    void zoomOut();
    void accelerer();
    void ralentir();
    void stopSimulation();
    void resumeSimulation();
    void demanderNombreVehicules();
    void onTuilesChargees();

private:
    void setupUI();
    void afficherCarte();
    void chargerTuilesOSM();

    QGraphicsScene* scene;
    QGraphicsView* mapView;
    QPushButton* loadOSMButton;
    QPushButton* zoomInButton;
    QPushButton* zoomOutButton;
    QPushButton* speedUpButton;
    QPushButton* slowButton;
    QPushButton* stopButton;
    QPushButton* resumeButton;

    Simulation* simulation;
    QTimer* timer;
    QTimer* renderTimer;  // Timer pour le rendu à 60 FPS
    OSMTileManager* tileManager;

    bool tilesLoaded;
};

#endif // MAINWINDOW_H
