#include "Vehicule.h"
#include "noeud.h"
#include <QGraphicsPixmapItem>
#include <QGraphicsSvgItem>
#include <cmath>
#include <unordered_set>
#include <QGraphicsPixmapItem>
#include <QGraphicsColorizeEffect>
#include <QColor>
#include <QDebug>

const double C = 3e8; // Vitesse de la lumière (m/s)


Vehicule::Vehicule(int ident, double p, double f)
    : id{ident}, puissance{p}, frequence{f}, position{nullptr},
    graphicItem{nullptr}, couvertureItem{nullptr}, noeudPrecedent(nullptr),
    versAvant{true}, indexCheminActuel{0},
    progressionMouvement{1.0}, vitesseDeplacement{0.015} // 0.015 = beaucoup plus lent !
{
    positionActuelle = QPointF(0, 0);
    positionCible = QPointF(0, 0);
}

int Vehicule::getId()
{
    return id;
}

noeud* Vehicule::getPosition() const
{
    return position;
}

void Vehicule::setPosition(noeud* val) {
    if (position != val && val != nullptr) {
        // Nouvelle cible détectée
        noeudPrecedent = position; // Sauvegarder l'ancienne position
        position = val;
        positionCible = val->geoToScene();
        progressionMouvement = 0.0; // Réinitialiser la progression

        qDebug() << "Véhicule" << id << "nouvelle cible:" << positionCible;
    }
}

double Vehicule::getPuissance()
{
    return puissance;
}

double Vehicule::getFrequence()
{
    return frequence;
}

void Vehicule::setPuissance(double val)
{
    puissance = val;
}

std::unordered_set<int> Vehicule::getConnexions() const
{
    return vehiclesConnectes;
}

QGraphicsItem* Vehicule::getEllipse() const
{
    return graphicItem;
}

void Vehicule::updatePositionSmooth() {
    if (progressionMouvement < 1.0) {
        // Augmenter la progression
        progressionMouvement += vitesseDeplacement;

        if (progressionMouvement > 1.0) {
            progressionMouvement = 1.0;
        }

        // Interpolation avec easing (courbe douce)
        // Fonction ease-in-out quadratique pour un mouvement plus naturel
        double t = progressionMouvement;
        double smoothT;

        if (t < 0.5) {
            smoothT = 2 * t * t; // Ease in
        } else {
            smoothT = -1 + (4 - 2 * t) * t; // Ease out
        }

        // Calculer la position interpolée
        QPointF depart = noeudPrecedent ? noeudPrecedent->geoToScene() : positionActuelle;
        positionActuelle = depart + (positionCible - depart) * smoothT;
    } else {
        // Mouvement terminé, position = cible
        if (position) {
            positionActuelle = position->geoToScene();
        }
    }
}

QPointF Vehicule::getPositionSmooth() const {
    return positionActuelle;
}

void Vehicule::setVitesseDeplacement(double vitesse) {
    // Limiter entre 0.01 (très lent) et 0.5 (très rapide)
    vitesseDeplacement = qBound(0.01, vitesse, 0.5);
}

void Vehicule::afficherDansScene(QGraphicsScene* scene) {
    if (!position) return;

    // Mettre à jour la position interpolée
    updatePositionSmooth();

    if (!graphicItem) {
        // Charger une image vectorielle SVG ou un pixmap
        QGraphicsSvgItem* svgItem = new QGraphicsSvgItem(":/voiture.svg");
        svgItem->setScale(0.01); // Ajuster la taille de l'image
        graphicItem = svgItem;
        graphicItem->setZValue(100); // Au-dessus de tout
        scene->addItem(graphicItem);

        // Initialiser la position actuelle
        positionActuelle = position->geoToScene();
        positionCible = positionActuelle;
        progressionMouvement = 1.0;
    }

    // Utiliser la position interpolée smooth
    QPointF positionScene = getPositionSmooth();
    QSizeF svgSize = graphicItem->boundingRect().size();
    QPointF svgOffset(svgSize.width() * 0.5 * graphicItem->scale(),
                      svgSize.height() * 0.5 * graphicItem->scale());
    graphicItem->setPos(positionScene - svgOffset);

    // Calculer le rayon de la couverture
    double rayon = calculerRayonCouverture();

    if (!couvertureItem) {
        // Créer une ellipse pour la zone de couverture (si elle n'existe pas)
        QColor couleurCouverture = QColor::fromHsv((id * 45) % 360, 255, 255);
        couvertureItem = new QGraphicsEllipseItem();
        couvertureItem->setBrush(QBrush(couleurCouverture, Qt::Dense4Pattern));
        couvertureItem->setPen(Qt::NoPen);
        couvertureItem->setOpacity(0.3);
        couvertureItem->setZValue(50);
        scene->addItem(couvertureItem);
    }

    // Mettre à jour la position et la taille de la zone de couverture (smooth aussi)
    couvertureItem->setRect(
        positionScene.x() - rayon,
        positionScene.y() - rayon,
        rayon * 2,
        rayon * 2
        );
}


void Vehicule::connecteDe(int idVB) {
    if (idVB == id || vehiclesConnectes.find(idVB) != vehiclesConnectes.end()) {
        return;
    }
    vehiclesConnectes.insert(idVB);
}

void Vehicule::deconnecteDe(int idVB) {
    vehiclesConnectes.erase(idVB);
}

bool Vehicule::estConnecteAvec(int idVB) const {
    return vehiclesConnectes.find(idVB) != vehiclesConnectes.end();
}

double Vehicule::calculerRayonCouverture() const {
    const double C = 3e8;
    double lambda = C / frequence;
    double rayon = std::sqrt((puissance * lambda * lambda) / (4 * M_PI * 1e-9));
    double rayonLimite = 40.0;
    return std::min(rayon, rayonLimite);
}

double Vehicule::calculerPuissance(double distance) const {
    if (distance <= 0.0) {
        return puissance;
    }

    double lambda = C / frequence;
    double puissanceRecue = (puissance * lambda * lambda) / (4 * M_PI * distance * distance);

    return puissanceRecue;
}

void Vehicule::setChemin(const QVector<noeud*>& nouveauChemin) {
    chemin = nouveauChemin;
    indexCheminActuel = 0;

    if (!chemin.isEmpty()) {
        position = chemin[0];
        positionActuelle = chemin[0]->geoToScene();
        positionCible = positionActuelle;
        progressionMouvement = 1.0;
        noeudPrecedent = nullptr;
    }
}

QVector<noeud*> Vehicule::getChemin() const {
    return chemin;
}

bool Vehicule::getVersAvant()
{
    return versAvant;
}

noeud* Vehicule::avancerChemin() {
    if (indexCheminActuel < chemin.size() - 1) {
        noeudPrecedent = chemin[indexCheminActuel];
        indexCheminActuel++;
        return chemin[indexCheminActuel];
    }
    versAvant = false;
    return nullptr;
}

noeud* Vehicule::reculerChemin(){
    if (indexCheminActuel > 0){
        noeudPrecedent = chemin[indexCheminActuel];
        indexCheminActuel--;
        return chemin[indexCheminActuel];
    }
    versAvant = true;
    return nullptr;
}

noeud* Vehicule::getPositionCheminActuel() const {
    if (indexCheminActuel < chemin.size()) {
        return chemin[indexCheminActuel];
    }
    return nullptr;
}
