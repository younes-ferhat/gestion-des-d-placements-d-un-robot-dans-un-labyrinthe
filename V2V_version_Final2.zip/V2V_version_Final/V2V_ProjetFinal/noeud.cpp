#include "noeud.h"
#include <cmath>

noeud::noeud(long long id, double lat, double lon)
    : id(id), latitude(lat), longitude(lon) {}

noeud::noeud(): id{100},latitude{333332},longitude{44444}
{

}

// Getters
long long noeud::getId() const {
    return id;
}

double noeud::getLatitude() const {
    return latitude;
}

double noeud::getLongitude() const {
    return longitude;
}

double noeud::X_lambert93() const {
    // Constantes pour Lambert 93
    const double a = 6378137.0;
    const double e = 0.0818191910428158;
    const double lambda0 = 3.0 * M_PI / 180.0;
    const double phi0 = 46.5 * M_PI / 180.0;
    const double n = 0.7256077650;
    const double c = 11754255.426;
    const double X0 = 700000.0;

    double phi = latitude * M_PI / 180.0;
    double lambda = longitude * M_PI / 180.0;

    double tanPhi = tan(M_PI / 4.0 + phi / 2.0);
    double tanPhiE = pow((1.0 - e * sin(phi)) / (1.0 + e * sin(phi)), e / 2.0);
    double L = log(tanPhi * tanPhiE);

    double R = c * exp(-n * L);
    double gamma = n * (lambda - lambda0);
    double x = X0 + R * sin(gamma);

    return x;
}

double noeud::Y_lambert93() const {
    const double a = 6378137.0;
    const double e = 0.0818191910428158;
    const double lambda0 = 3.0 * M_PI / 180.0;
    const double phi0 = 46.5 * M_PI / 180.0;
    const double n = 0.7256077650;
    const double c = 11754255.426;
    const double Y0 = 6600000.0;

    double phi = latitude * M_PI / 180.0;
    double lambda = longitude * M_PI / 180.0;

    double tanPhi = tan(M_PI / 4.0 + phi / 2.0);
    double tanPhiE = pow((1.0 - e * sin(phi)) / (1.0 + e * sin(phi)), e / 2.0);
    double L = log(tanPhi * tanPhiE);

    double R = c * exp(-n * L);
    double gamma = n * (lambda - lambda0);
    double y = Y0 - R * cos(gamma);

    return y;
}

// Conversion en coordonnées Web Mercator (pour correspondre aux tuiles OSM)
QPointF noeud::geoToScene() const {
    // Niveau de zoom utilisé pour les tuiles
    const int zoom = 15;
    const int tileSize = 256;

    // Conversion lat/lon vers coordonnées de pixel Web Mercator
    int n = 1 << zoom; // 2^zoom

    double latRad = latitude * M_PI / 180.0;

    // Formules Web Mercator
    double worldX = (longitude + 180.0) / 360.0 * n;
    double worldY = (1.0 - log(tan(latRad) + 1.0 / cos(latRad)) / M_PI) / 2.0 * n;

    // Convertir en pixels
    double pixelX = worldX * tileSize;
    double pixelY = worldY * tileSize;

    return QPointF(pixelX, pixelY);
}

QVector<noeud*> noeud::getNoeudsVoisins() const {
    return noeudsVoisins;
}

// Ajouter un voisin
void noeud::ajouterVoisin(noeud* voisin) {
    if (!noeudsVoisins.contains(voisin)) {
        noeudsVoisins.append(voisin);
    }
}
