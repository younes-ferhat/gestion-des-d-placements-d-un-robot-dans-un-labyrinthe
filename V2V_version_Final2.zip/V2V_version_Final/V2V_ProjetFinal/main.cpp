#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    MainWindow mainWindow;
    mainWindow.setWindowTitle("Simulation V2V - M1 MIAGE-INFO");
    mainWindow.show();

    return app.exec();
}
