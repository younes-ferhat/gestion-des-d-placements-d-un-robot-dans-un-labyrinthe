#include "hexagone.h"
#include <QPolygonF>
#include <QBrush>
hexagone::hexagone(QPointF p, double rayon)
    : d_rayon{rayon}, d_centre{p}, d_estActif{false} {
    vector<QPointF> points = calculPoints();

    QPolygonF polygon;
    for (const auto& sommet : points) {
        polygon << QPointF(sommet.x(), sommet.y());
    }

    setPolygon(polygon);

    // D�finir un contour noir et un remplissage transparent
    setBrush(QBrush(Qt::transparent));
    setPen(QPen(Qt::black, 1)); // Contour noir avec une �paisseur de 1
}


QPointF hexagone::getCentre() const {
    return d_centre;
}

double hexagone::getRayon() const {
    return d_rayon;
}

vector<QPointF> hexagone::calculPoints() const {
    vector<QPointF> points;
    double angle_debut = M_PI / 6;  // D�but � 30 degr�s
    for (int i = 0; i < 6; ++i) {
        double angle = angle_debut + i * M_PI / 3;  // 60 degr�s entre chaque sommet
        double pointX = d_centre.x() + getRayon() * cos(angle);
        double pointY = d_centre.y() + getRayon() * sin(angle);
        points.emplace_back(pointX, pointY);
    }
    return points;
}

bool hexagone::estActif() const {
    return d_estActif;
}

void hexagone::setActif(bool actif) {
    d_estActif = actif;
}

/*bool hexagone::contientVehicule(const Vehicule& vehicule) const {
    QPoint vehiculePos = vehicule.geoToScene(vehicule.getPosition().getLongitude(),vehicule.getPosition().getLatitude());
    vector<QPoint> pointsHexagone = calculPoints();

    int n = pointsHexagone.size();
    bool result = false;

    for (int i = 0, j = n - 1; i < n; j = i++) {
        if (((pointsHexagone[i].y() > vehiculePos.y()) != (pointsHexagone[j].y() > vehiculePos.y())) &&
            (vehiculePos.x() < (pointsHexagone[j].x() - pointsHexagone[i].x()) * (vehiculePos.y() - pointsHexagone[i].y()) / (pointsHexagone[j].y() - pointsHexagone[i].y()) + pointsHexagone[i].x())) {
            result = !result;
        }
    }

    return result;
}

void hexagone::colorierVert(const Vehicule& vehicule) {
    if (contientVehicule(vehicule)) {
        setBrush(QBrush(Qt::green));  // Changer la couleur de remplissage en vert
        update();                     // Actualiser le dessin
    }
}
*/
