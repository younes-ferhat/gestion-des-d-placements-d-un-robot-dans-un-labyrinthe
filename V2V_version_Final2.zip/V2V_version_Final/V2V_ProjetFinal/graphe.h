#ifndef GRAPHE_H
#define GRAPHE_H

#include "noeud.h"
#include "arete.h"
#include <QMap>
#include <QVector>
#include <QString>
#include <QGraphicsScene>

class graphe {
private:
    QMap<long long, noeud*> listeNoeuds; // Clé : ID du nœud (TOUS les nœuds)
    QVector<arete*> listeAretes;
    QMap<long long, noeud*> listeNoeudsReferences; // Nœuds sur les routes praticables

    // Vérifier la connectivité du graphe
    void verifierConnectivite();

public:
    graphe();

    // Getters
    QMap<long long, noeud*> getListeNoeuds() const;
    QMap<long long, noeud*> getListeNoeudsReferences() const;
    QVector<arete*> getListeAretes() const;

    // Ajout
    void ajouteNoeud(noeud* node);
    void ajouteArete(arete* edge);
    noeud* getNoeudAleatoire() const;

    // Méthode pour charger un fichier OSM
    void chargerDepuisOSM(const QString& fichierOSM);

    void testerNoeudVoisins() const;
    void afficherGraphe(QGraphicsScene* scene) const;
    QRectF obtenirLimitesGeo() const;
    QVector<noeud*> calculerCheminDijkstra(noeud* debut, noeud* fin);
};

#endif // GRAPHE_H
