#ifndef OSMTILEMANAGER_H
#define OSMTILEMANAGER_H

#include <QObject>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QPixmap>
#include <QMap>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QPair>

class OSMTileManager : public QObject {
    Q_OBJECT

public:
    explicit OSMTileManager(QObject* parent = nullptr);
    ~OSMTileManager();

    // Charger les tuiles pour une zone géographique donnée
    void chargerTuilesPourZone(QGraphicsScene* scene, double minLat, double maxLat,
                               double minLon, double maxLon, int zoomLevel = 15);

    // Convertir lat/lon en coordonnées de tuiles
    static QPair<int, int> latLonToTile(double lat, double lon, int zoom);

    // Convertir coordonnées de tuiles en pixels de la scène
    QPointF tileToScene(int tileX, int tileY, int zoom) const;

    // Nettoyer les tuiles chargées
    void clear();

signals:
    void tuileChargee(int tileX, int tileY);
    void toutesChargees();

private slots:
    void onTuileTelechargee();

private:
    QNetworkAccessManager* networkManager;
    QMap<QPair<int, int>, QGraphicsPixmapItem*> tuiles;
    QGraphicsScene* currentScene;
    int totalTuiles;
    int tuilesChargees;
    int currentZoom;

    // Télécharger une tuile spécifique
    void telechargerTuile(int tileX, int tileY, int zoom);

    // Cache local des tuiles
    QString getCachePath(int tileX, int tileY, int zoom) const;
    void sauverDansCache(int tileX, int tileY, int zoom, const QByteArray& data);
    bool chargerDepuisCache(int tileX, int tileY, int zoom, QPixmap& pixmap);
};

#endif // OSMTILEMANAGER_H
